define([
		"qlik", 
		"jquery", 
		"./lib/js/ping-pong-chart-properties",
		"./lib/js/ping-pong-chart-initialprops",		
		"text!./lib/css/ping-pong-chart.css",
		"text!./ping-pong-chart.html"	
	],
	function(qlik, $, props, initProps, cssContent, template) {
		'use strict';
		var support = {
			snapshot: false,
			export: false,
			exportData : false
		};

		$("<style>").html(cssContent).appendTo("head");
		
		return {
			initialProperties : initProps,
			definition : props,
			support : support,
			template: template,

			controller: ['$scope', function ( $scope ) {
				const app = qlik.currApp(this);	
				const self = this;												
				let firstRender = true;
				let qData = $scope.layout.qHyperCube.qDataPages[0];
				let drawHeight = $('.qv-object-ping-pong-chart').innerHeight();
				let drawWidth = $('.qv-object-ping-pong-chart').innerWidth();

				const canvas = document.querySelector('#ping-pong');
				canvas.width = drawWidth;
				canvas.height = drawHeight;
				const context = canvas.getContext('2d');				
				$scope.circleArray = [];
				$scope.value = -1;
				
				const init = function(){
					$scope.circleArray.length = 0;
					if(qData && qData.qMatrix) {
						qData.qMatrix.forEach(function(row) {
							if(row.length > 1) {
								//console.log(row, "tracking");								
								const emoji = row[0].qText;
								const value = row[1].qText;
								const dim = row[0];									
								const radius = value * 5 + 10;
								const x = Math.random() * (drawWidth - radius  * 2) + radius;
								const y = Math.random() * (drawHeight - radius  * 2) + radius;
								const dx = (Math.random() - 0.5) * 2;
								const dy = (Math.random() - 0.5) * 2;
								let engineId =-1;								
								
								if(dim.qElemNumber !== -1) {
									engineId = dim.qElemNumber
								}

								$scope.circleArray.push(new Circle(x, y, dx, dy, radius, emoji, engineId));								
							}
						})
					};					
				};
				
				const Circle = function(x, y, dx, dy, radius, emoji, id) {
					this.x = x
					this.y = y
					this.dx = dx
					this.dy = dy
					this.radius = radius
					this.minRadius = radius
					this.emoji = emoji;
					this.id = id;
					/* this.colour = colour == 0 ? "white": "red"; */
					
					this.draw = function() {
						context.font = this.radius+'px Courier New';

						/* context.strokeStyle = this.colour;
						context.lineWidth = 5;
						context.strokeText(this.emoji, this.x, this.y); */

						context.fillText(this.emoji, this.x, this.y)						
					}
					
					this.update = function() {
						if (this.x + this.radius > drawWidth || this.x < 0) {
							this.dx = -this.dx
						}
						if (this.y  > drawHeight || this.y - this.radius < 0) {
							this.dy = -this.dy
						}
						this.x += this.dx
						this.y += this.dy	
						this.draw();
					}
				}

				const animate = function(){
					requestAnimationFrame(animate)
					context.clearRect(0, 0, drawWidth, drawHeight)

					for (let i = 0; i < $scope.circleArray.length; i++) {
						$scope.circleArray[i].update() 
					}
				}

				$scope.Draw = function(){					
					if(!firstRender){
						qData = $scope.layout.qHyperCube.qDataPages[0];						
						drawHeight = $('.qv-object-ping-pong-chart').innerHeight();
						drawWidth = $('.qv-object-ping-pong-chart').innerWidth();						
						canvas.width = drawWidth;
						canvas.height = drawHeight;
					}
					init();
					canvas.addEventListener('click', function(e) {
						var rect = e.target.getBoundingClientRect();
						var x = e.clientX - rect.left; //x position within the element.
						var y = e.clientY - rect.top;  //y position within the element.

						$scope.circleArray.forEach(function(element) {							
							if (x > element.x && x < element.x + element.radius
								&& y > element.y - element.radius && y < element.y)
							{
								//console.log(element.emoji);
								$scope.value = element.id;															
							}else{
								//console.log(element.x + "----"+ x,"y")
							}
						});
					}, true);					
				}
				$scope.Draw();
				animate();				
				$scope.selection = function(){
					if($scope.value != -1){
						$scope.selectValues(0, [$scope.value], true);
						$scope.message=-1;
					}					
				}

				firstRender = false;
			}],
			
			paint : function($element) {
				this.$scope.Draw();
				return qlik.Promise.resolve();
			}
		};
	}
);
